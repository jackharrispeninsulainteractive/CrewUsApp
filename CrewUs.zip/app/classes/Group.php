<?php
/**
 * Copyright Jack Harris
 * Peninsula Interactive - PHS-L&E
 * Last Updated - 13/05/2021
 */

class Group
{

    private InterfaceAlert $alert;
    private Config $config;
    private string $uploadDirectory = "./uploads/groups";

}